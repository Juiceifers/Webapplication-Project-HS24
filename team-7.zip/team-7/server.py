from flask import Flask, request, jsonify, flash, redirect, url_for
import database  # Import your database functions
import os
from werkzeug.utils import secure_filename
from flask_cors import CORS
from Mert_testing import summarizer
from topic_mods.main import process_file

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Initialize the SQLite database
database.create_table()  # Ensure the table is created

# Routes for registration and login
@app.route('/register', methods=['POST'])
def register():
    username = request.json.get('username')
    password = request.json.get('password')

    # Check if the user already exists in the database
    if database.get_user(username):
        return jsonify({"success": False, "message": "User already exists"})
    
    # Add user to the database
    database.add_user(username, password)
    return jsonify({"success": True, "message": "User registered successfully"})

@app.route('/login', methods=['POST'])
def login():
    username = request.json.get('username')
    password = request.json.get('password')

    # Fetch user from the database
    user = database.get_user(username)
    if user and user[2] == password:  # Compare stored password (user[2]) with the entered password
        return jsonify({"success": True, "username": username})
    else:
        return jsonify({"success": False, "message": "Invalid username or password"})

# File upload route
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    print("FILE UPLOAD RECEIVED")
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file, the browser submits an
        # empty file without a filename.
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            fpath = f"uploads/{filename}"

            process_file(fpath)
            summarizer.summarize_pdf(fpath)

    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''

if __name__ == '__main__':
    print("starting flask API")
    app.run(host='0.0.0.0', port=5000)
